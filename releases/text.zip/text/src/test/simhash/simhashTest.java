package test.simhash; 

import IO.IOUtils;
import hanlp.hanlp;
import org.junit.Test;
import org.junit.Before; 
import org.junit.After;
import simhash.simhash;

import java.util.ArrayList;

/** 
* simhash Tester. 
* 
* @author <Authors name> 
* @since <pre>9�� 21, 2022</pre> 
* @version 1.0 
*/ 
public class simhashTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: simHash(ArrayList<String> TermList) 
* 
*/ 
@Test
public void testSimHash() throws Exception { 
//TODO: Test goes here...
    IOUtils IOU = new IOUtils();
    hanlp han = new hanlp();
    String s = IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig.txt");
    String s1 = IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_add.txt");
    String s2 = IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_del.txt");
    String s3 = IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_dis_1.txt");
    String s4 = IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_dis_10.txt");
    String s5 = IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_dis_15.txt");
    ArrayList<String> term = han.separate(s);
    ArrayList<String> term2 = han.separate(s1);
    ArrayList<String> term3 = han.separate(s2);
    ArrayList<String> term4 = han.separate(s3);
    ArrayList<String> term5 = han.separate(s4);
    ArrayList<String> term6 = han.separate(s5);
    simhash sim = new simhash(64,term);
    simhash sim2 = new simhash(64,term2);
    simhash sim3 = new simhash(64,term3);
    simhash sim4 = new simhash(64,term4);
    simhash sim5 = new simhash(64,term5);
    simhash sim6 = new simhash(64,term6);


    System.out.println("文本相似度为"+sim.getSemblance(sim2));
    System.out.println("文本相似度为"+sim.getSemblance(sim3));
    System.out.println("文本相似度为"+sim.getSemblance(sim4));
    System.out.println("文本相似度为"+sim.getSemblance(sim5));
    System.out.println("文本相似度为"+sim.getSemblance(sim6));




} 

/** 
* 
* Method: hammingDistance(simhash s2) 
* 
*/ 
@Test
public void testHammingDistance() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getSemblance(simhash s2) 
* 
*/ 
@Test
public void testGetSemblance() throws Exception { 
//TODO: Test goes here... 
} 


/** 
* 
* Method: hash(String s) 
* 
*/ 
@Test
public void testHash() throws Exception { 
//TODO: Test goes here... 
/* 
try { 
   Method method = simhash.getClass().getMethod("hash", String.class); 
   method.setAccessible(true); 
   method.invoke(<Object>, <Parameters>); 
} catch(NoSuchMethodException e) { 
} catch(IllegalAccessException e) { 
} catch(InvocationTargetException e) { 
} 
*/ 
} 

} 
