package test.IO; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After;

import static com.hankcs.hanlp.corpus.io.IOUtil.readTxt;

/** 
* IOUtils Tester. 
* 
* @author <Authors name> 
* @since <pre>9�� 20, 2022</pre> 
* @version 1.0 
*/ 
public class IOUtilsTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: readTxt(String FIN) 
* 
*/ 
@Test
public void testReadTxt() throws Exception {
readTxt("D:\\idea_project\\text\\�����ı�\\oig.txt");
readTxt("");

}
}
