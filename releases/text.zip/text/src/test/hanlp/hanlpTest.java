package test.hanlp; 

import hanlp.hanlp;
import org.junit.Test;
import org.junit.Before; 
import org.junit.After; 

/** 
* hanlp Tester. 
* 
* @author <Authors name> 
* @since <pre>9�� 21, 2022</pre> 
* @version 1.0 
*/ 
public class hanlpTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: separate(String txt) 
* 
*/ 
@Test
public void testSeparate() throws Exception { 
//TODO: Test goes here...
    String s = "一位真正的作家永远只为内心写作，只有内心才会真实地告诉他，他的自私、他的高尚是多么突出。";
    String s1 = "长期以来，我的作品都是源出于和现实的那一层紧张关系。";
    String s2 = "前面已经说过，我和现实关系紧张，说得严重一些，我一直是以敌对的态度看待现实。。";
    String s3 = "就是这篇《活着》，写人对苦难的承受能力，对世界乐观的态度。。";
    String s5 = "我";
    hanlp han = new hanlp();
    System.out.println(han.separate(s));
    System.out.println(han.separate(s1));
    System.out.println(han.separate(s2));
    System.out.println(han.separate(s3));
    System.out.println(han.separate(s5));

} 


} 
