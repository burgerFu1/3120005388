package test;

import IO.IOUtils;
import hanlp.hanlp;
import org.junit.Test;
import org.junit.Before; 
import org.junit.After;
import simhash.simhash;

import java.util.ArrayList;

/** 
* Main Tester. 
* 
* @author <Authors name> 
* @since <pre>9�� 21, 2022</pre> 
* @version 1.0 
*/ 
public class MainTest { 

@Test
public void compare(){
    IOUtils IOU = new IOUtils();
    hanlp han = new hanlp();
    String s =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig.txt");
    String s2 =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_add.txt");
    ArrayList<String> term = han.separate(s);
    ArrayList<String> term2 = han.separate(s2);
    simhash sim = new simhash(64,term);
    simhash sim2 = new simhash(64,term2);
    System.out.println(sim.hammingDistance(sim2));
    System.out.println(sim.getSemblance(sim2));
}
    @Test
public void compare1(){
        IOUtils IOU = new IOUtils();
        hanlp han = new hanlp();
        String s =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig.txt");
        String s2 =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_del.txt");
        ArrayList<String> term = han.separate(s);
        ArrayList<String> term2 = han.separate(s2);
        simhash sim = new simhash(64,term);
        simhash sim2 = new simhash(64,term2);
        System.out.println(sim.hammingDistance(sim2));
        System.out.println(sim.getSemblance(sim2));
    }
    @Test
    public void compare2(){
        IOUtils IOU = new IOUtils();
        hanlp han = new hanlp();
        String s =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig.txt");
        String s2 =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_dis_1.txt");
        ArrayList<String> term = han.separate(s);
        ArrayList<String> term2 = han.separate(s2);
        simhash sim = new simhash(64,term);
        simhash sim2 = new simhash(64,term2);
        System.out.println(sim.hammingDistance(sim2));
        System.out.println(sim.getSemblance(sim2));
    }
    @Test
    public void compare3(){
        IOUtils IOU = new IOUtils();
        hanlp han = new hanlp();
        String s =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig.txt");
        String s2 =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_dis_10.txt");
        ArrayList<String> term = han.separate(s);
        ArrayList<String> term2 = han.separate(s2);
        simhash sim = new simhash(64,term);
        simhash sim2 = new simhash(64,term2);
        System.out.println(sim.hammingDistance(sim2));
        System.out.println(sim.getSemblance(sim2));
    }
    @Test
    public void compare4(){
        IOUtils IOU = new IOUtils();
        hanlp han = new hanlp();
        String s =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig.txt");
        String s2 =IOU.readTxt("D:\\idea_project\\text\\text_ext\\orig_0.8_dis_15.txt");
        ArrayList<String> term = han.separate(s);
        ArrayList<String> term2 = han.separate(s2);
        simhash sim = new simhash(64,term);
        simhash sim2 = new simhash(64,term2);
        System.out.println(sim.hammingDistance(sim2));
        System.out.println(sim.getSemblance(sim2));
    }



} 
